package lk.ijse.gym;

public class    LauncherWrapper {
    public static void main(String[] args) {
        Launcher.main(args);
    }

}
