package lk.ijse.gym.Dao.Custom;

import lk.ijse.gym.dto.MemberDto;

import java.sql.SQLException;
import java.util.List;

public interface MemberDao {
    MemberDto search(String memberId) throws SQLException;

    boolean save(MemberDto dto) throws SQLException;

    List<MemberDto> getAll() throws SQLException;

    boolean delete(String memberId) throws SQLException;

    boolean update(MemberDto dto) throws SQLException;

}
