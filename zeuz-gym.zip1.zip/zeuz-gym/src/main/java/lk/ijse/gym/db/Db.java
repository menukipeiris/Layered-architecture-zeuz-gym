package lk.ijse.gym.db;

public class Db {
    public     static  final  String USERNAME="menuki";
    public   static  final  String PASSWORD="1234";

}
