package lk.ijse.gym.Dao.Custom;

public interface EmployeeDao {

}
