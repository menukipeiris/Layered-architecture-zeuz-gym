package lk.ijse.gym.Dao;

import lk.ijse.gym.dto.MemberDto;

import java.sql.SQLException;
import java.util.List;

public interface CrudDao<T> {
    T search(String memberId) throws SQLException;

    boolean save(T dto) throws SQLException;

    List<T> getAll() throws SQLException;

    boolean delete(String memberId) throws SQLException;

    boolean update(T dto) throws SQLException;
}
